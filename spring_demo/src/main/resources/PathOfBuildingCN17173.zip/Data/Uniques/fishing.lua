﻿-- Item data (c) Grinding Gear Games

return {
-- Weapon: Fishing Rod
[[
Reefbane
Fishing Rod
Variant: Pre 2.6.0
Variant: Current
Requires 8 Str, 8 Dex
(30-40)% increased Cast Speed
Thaumaturgical Lure
{variant:1}(30-40)% increased Quantity of Fish Caught
{variant:2}(10-20)% increased Quantity of Fish Caught
Glows while in an Area containing a Unique Fish
]],[[
Song of the Sirens
Fishing Rod
Requires 8 Str, 8 Dex
Implicits: 0
Siren Worm Bait
(50-40)% reduced Quantity of Fish Caught
(50-60)% increased Rarity of Fish Caught
You can catch Exotic Fish
]]
}

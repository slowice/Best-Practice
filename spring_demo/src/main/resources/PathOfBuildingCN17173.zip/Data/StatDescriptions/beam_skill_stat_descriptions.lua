return {
	[1]={
		lang={
			["Simplified Chinese"]={
				[1]={
					limit={
						[1]={
							[1]=1,
							[2]=1
						}
					},
					text="射线会分裂射击 {0} 个额外目标"
				},
				[2]={
					limit={
						[1]={
							[1]="#",
							[2]="#"
						}
					},
					text="射线会分裂射击 {0} 个额外目标"
				}
			}
		},
		name="base_split_num",
		stats={
			[1]="projectile_number_to_split"
		}
	},
	parent="skill_stat_descriptions",
	["projectile_number_to_split"]=1
}